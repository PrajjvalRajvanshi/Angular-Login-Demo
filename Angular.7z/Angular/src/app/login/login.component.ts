import {Component, OnInit} from '@angular/core';
import { invalid } from '@angular/compiler/src/render3/view/util';

@Component({
    selector:'app-login',
    templateUrl:'login.component.html'
})

export class LoginComponent implements OnInit{
    
    username="Prince"
    password="hello"
    invalidLogin = false

    handleLogin():any{
        // console.log(this.username)
        // console.log(this.password)
        if(this.username === "Prince" && this.password === "hello"){
                this.invalidLogin=false;
                console.log("Valid")
        }  
        else{
            this.invalidLogin=true;
            console.log("Not Valid")
        }
    }
    
    ngOnInit(){

    }

    constructor(){

    }
}